module AkiHelper
end
