class AkiController < ApplicationController
  def home
  	@time=Time.new
  end

  def contact
  end
end
