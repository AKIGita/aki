require 'test_helper'

class AkiHelperTest < ActionView::TestCase
end
